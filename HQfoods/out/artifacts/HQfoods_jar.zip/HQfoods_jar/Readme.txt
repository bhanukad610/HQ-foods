This simple java application is to maintain food chart of HQ :)
open run.bat
TADAAA

| HQ ICE16 |
#BM>